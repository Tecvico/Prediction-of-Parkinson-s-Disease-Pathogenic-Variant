clc;
clear;
filename = "LEDD_Inc_54CS01V4";
f = filename + ".xlsx";
data = readtable(f,'ReadVariableNames',true , 'Sheet', 'Sheet1' );  
target = readtable(f,'ReadVariableNames',true , 'Sheet', 'Sheet2' ); 

Num_features=93;

%% 

% files = ["cfs" ,"fsasl","fsv","L0","laplacian" , "lasso","llcfs","mrmr" ,"relieff" ,"UDFS","ufsol" ];
% files = ["mrmr" ];

files = dir('Data\\');
files(1:2) = [];
for i=1 : size(files,1)
    nameFSA = files(i).name;
    PATH_fsa = 'Data\\'+string(nameFSA)+'\\*.mat';
    rankfiles = dir(PATH_fsa);
    PATH = 'Data\\'+string(nameFSA)+'\\'+rankfiles.name;

    load(PATH)
  
    if (size(ranking,2) == 1)
        ranking = ranking.';
    end
    
    features = ranking(:,1:Num_features);
    features = sort(features);
    selected_data = data(:,features);    
    var = selected_data.Properties.VariableNames;
    varName(i,:) = [ nameFSA , var];
end
% xlswrite(reducedFilename,SRdata,'Data')


