import numpy as np
from numpy import mean
from numpy import std
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score 
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import auc
from sklearn.metrics import roc_curve

class ClassificationMetrics :

    def __init__(self, predictorName = '' , contin = False , DatasetName = '',best = ''):
        self.predictorName = predictorName
        self.contin = contin
        self.DatasetName = DatasetName
        self.best = best

    # getter method
    def get_best(self):
        return self._best
      
    # setter method
    def set_best(self, x):
        self._best = x

     # getter method
    def get_DatasetName(self):
        return self._DatasetName
      
    # setter method
    def set_DatasetName(self, x):
        self._DatasetName = x


    # getter method
    def get_predictorName(self):
        return self._predictorName
      
    # setter method
    def set_predictorName(self, x):
        self._predictorName = x


    # getter method
    def get_contin(self):
        return self._contin
      
    # setter method
    def set_contin(self, x):
        self._contin = x

    def Results(self,metr,res):
        Avg = mean(res)
        Std = std(res)
        out = metr + "\tmean : " + str(Avg)  +  "\tstd : "  +  str(Std) + "\n"
        # print(metr,"\tmean : ",Avg , "\tstd : " , Std)
        file = open("Results.txt", "a")
        file.write(out)
        file.close()


    def Print(self , Name):
        out = Name + " : \n"
        # print("\n"+Name+" : ")
        file = open("Results.txt", "a")
        file.write(out)
        file.close()  

    def PrintbestParameters(self):
        AlgName = self.get_predictorName()
        FEA_FSA = self.get_DatasetName()
        best = self.get_best()
        filename = 'Best_Parameters//' + FEA_FSA +'//'+ AlgName + '.txt'
        file = open(filename, "a")      
        file.write(best)
        file.close()  

    # def confusion_matrix_scorer(self,clf, X, y):
    #     y_pred = clf.predict(X)

    #     AlgName = self.get_predictorName()
    #     FEA_FSA = self.get_DatasetName()
    #     filename = 'Predict//' + FEA_FSA +'//'+ AlgName + '.txt'
    #     file = open(filename, "a")
    #     c = 0
    #     if self.get_contin() == False:
    #         for i in y:
    #             out = str(y[c])+ "\t" +str(y_pred[c]) + "\n"
    #             c = c + 1
    #             file.write(out)
    #         self.set_contin(True)
    #     else:
    #         self.set_contin(False)

    #     file.close()  



    #     cm = confusion_matrix(y, y_pred)
    #     ac = accuracy_score(y, y_pred)
    #     MisclassificationRate = 1 - ac
    #     # ErrorRate = 1 - ac
    #     # FalseNegativeRate = cm[1, 0] / (cm[1, 0]+cm[1, 1])
    #     Specificity =  cm[0, 0] / (cm[0, 1]+cm[0, 0])  # maybe wrong
    #     re = recall_score(y, y_pred, average='weighted' , zero_division=0)
    #     Sensitivity = re
    #     # TruePositiveRate = re
    #     pr = precision_score(y, y_pred, average='weighted', zero_division=0)
    #     fs = f1_score(y, y_pred, average='weighted', zero_division=0)
    #     roc = roc_auc_score(y, y_pred,average='weighted')
    #     fpr, tpr, thresholds = roc_curve(y, y_pred)
    #     aucScore = auc(fpr, tpr)
    #     fpr = np.mean(fpr)
    #     tpr = np.mean(tpr)

    #     return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1] 
    #     , 'acc': ac , 'Specificity':Specificity , 'MisclassificationRate': MisclassificationRate , 're': re , 'Sensitivity': Sensitivity , 'pre': pr , 'f_sc': fs
    #     , 'roc':roc , 'fpr':fpr , 'tpr':tpr , 'auc':aucScore 
    #     }   
    # 
    # 
    def confusion_matrix_scorer(self,clf, X, y):
        y_pred = clf.predict(X)

        AlgName = self.get_predictorName()
        FEA_FSA = self.get_DatasetName()
        filename = 'Predict//' + FEA_FSA +'//'+ AlgName + '.txt'
        file = open(filename, "a")
        c = 0
        if self.get_contin() == False:
            for i in y:
                out = str(y[c])+ "\t" +str(y_pred[c]) + "\n"
                c = c + 1
                file.write(out)
            self.set_contin(True)
        else:
            self.set_contin(False)

        file.close()  



        cm = confusion_matrix(y, y_pred)
        ac = accuracy_score(y, y_pred)
        MisclassificationRate = 1 - ac

        # Specificity =  cm[0, 0] / (cm[0, 1]+cm[0, 0])
        re = recall_score(y, y_pred, average='weighted' , zero_division=0)
        Sensitivity = re

        pr = precision_score(y, y_pred, average='weighted', zero_division=0)
        fs = f1_score(y, y_pred, average='weighted', zero_division=0)

        return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1] 
        , 'acc': ac  , 'MisclassificationRate': MisclassificationRate , 're': re , 'Sensitivity': Sensitivity , 'pre': pr , 'f_sc': fs
        } 


    def Externalscorer(self,clf, X, y, X_external, y_external):
        
        clf.fit(X, y)
        y_pred = clf.predict(X_external)
        
        AlgName = self.get_predictorName()
        FEA_FSA = self.get_DatasetName()
        filename = 'External_Predict//' + FEA_FSA +'//'+ AlgName + '.txt'
        file = open(filename, "a")

        c = 0 
        for i in y_external:
            out = str(y_external[c])+ "\t" +str(y_pred[c]) + "\n"
            file.write(out)
            c= c+1
        file.close()  


        cm = confusion_matrix(y_external, y_pred)
        ac = accuracy_score(y_external, y_pred)
        MisclassificationRate = 1 - ac
        re = recall_score(y_external, y_pred, average='weighted' , zero_division=0)
        Sensitivity = re
        pr = precision_score(y_external, y_pred, average='weighted', zero_division=0)
        fs = f1_score(y_external, y_pred, average='weighted', zero_division=0)

        return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1] 
        , 'acc': ac  , 'MisclassificationRate': MisclassificationRate , 're': re , 'Sensitivity': Sensitivity , 'pre': pr , 'f_sc': fs
        } 
    

    def PrintExternalResults(self , MetricName,res):
        out = MetricName + "\t" + str(res)  + "\n"
        print(MetricName,"\t",res)
        file = open("Results.txt", "a")
        file.write(out)
        file.close()    