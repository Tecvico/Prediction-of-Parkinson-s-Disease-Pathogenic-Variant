function K = from_data(kern,dat1,dat2,ind1,ind2,kerParam),

    K=get_x(dat1,ind1,dat2.index(ind2))';

  
  
 