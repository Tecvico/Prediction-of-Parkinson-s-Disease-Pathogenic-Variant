
function ret = testing(algo,dat)
   
  ret=feval(algo.type,algo,dat); 
